package SubClasses.map;

import javax.swing.*;


import java.awt.*;
import java.awt.event.*;


public class Map extends JFrame implements ActionListener{

    JButton EXIT_BUTTON = new JButton("EXIT");
    JLayeredPane MainGamePanel;
    JPanel BACKGROUND_PANEL = new JPanel();

    JLabel PopupLabel = new JLabel("Day: ");

    static final int GAME_WIDTH = 1200;
    static final int GAME_HEIGHT = 600;
    static final Dimension SCREEN_SIZE = new Dimension(GAME_WIDTH, GAME_HEIGHT);

    JLabel MapDay1Label = new JLabel();
    ImageIcon  Map = new ImageIcon("Map.png");

    JLabel MapDay2Label = new JLabel();
    ImageIcon  LongMap = new ImageIcon("LongMap.png");

    JLabel MapDay3Label = new JLabel();
    ImageIcon  MapByFour = new ImageIcon("MapByFour.png");

    JLabel MapDay4Label = new JLabel();
    ImageIcon  LongMapByFour = new ImageIcon("LongMapByFour.png");

    JLabel MapTest1 = new JLabel();

//    JPanel Day0 = new JPanel();
//    JPanel D1C1 = new JPanel();
//    JPanel D1C2 = new JPanel();



    public Map(int MapData){

        MainGamePanel = new JLayeredPane();
        MainGamePanel.setPreferredSize(SCREEN_SIZE);

        this.setPreferredSize(SCREEN_SIZE);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setTitle("Map");
        this.setResizable(false);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);

//        HandlerClass0 handlerDay0 = new HandlerClass0();
//        HandlerClass1C1 handlerDay1C1 = new HandlerClass1C1();
//        HandlerClass1C2 handlerDay1C2 = new HandlerClass1C2();
//
//        Day0.setBackground(Color.RED);
//        Day0.setBounds(646,542,10,10);
//        Day0.addMouseListener(handlerDay0);
//
//        D1C1.setBackground(Color.RED);
//        D1C1.setBounds(605,489,10,10);
//        D1C1.addMouseListener(handlerDay1C1);
//
//        D1C2.setBackground(Color.RED);
//        D1C2.setBounds(685,489,10,10);
//        D1C2.addMouseListener(handlerDay1C2);

        BACKGROUND_PANEL.setOpaque(true);
        BACKGROUND_PANEL.setSize(SCREEN_SIZE);
        BACKGROUND_PANEL.setBackground(new Color(50,50,50));

        EXIT_BUTTON.setVisible(true);
        EXIT_BUTTON.setBounds(1000,500,100,50);
        EXIT_BUTTON.setBackground(new Color(0,250,0));
        EXIT_BUTTON.setFocusable(false);
        EXIT_BUTTON.setFont(new Font("Arial", Font.BOLD, 10));
        EXIT_BUTTON.addActionListener(this);

        PopupLabel.setVisible(true);
        PopupLabel.setBackground(new Color(250,250,250));
        PopupLabel.setForeground(new Color(250,250,250));
        PopupLabel.setLocation(25,375);
        PopupLabel.setSize(300, 300);
        PopupLabel.setFont(new Font("Arial", Font.BOLD, 25));

        MapTest1.setText(Integer.toString (MapData));
        MapTest1.setFont(new Font("Arial", Font.BOLD, 25));
        MapTest1.setBounds(10, 10, 100, 100);
        MapTest1.setVisible(true);
        MapTest1.setBackground(new Color(250,250,250));
        MapTest1.setForeground(new Color(250,250,250));


        MapDay1Label.setVisible(true);
        MapDay1Label.setIcon(LongMap);
        MapDay1Label.setLocation(550,400);
        MapDay1Label.setSize(300, 300);

//        MapDay1Label.setVisible(true);
//        MapDay1Label.setIcon(LongMap);
//        MapDay1Label.setLocation(300,100);
//        MapDay1Label.setSize(600, 400);

        MapDay4Label.setVisible(true);
        MapDay4Label.setIcon(LongMap);
        MapDay4Label.setLocation(50,50);
        MapDay4Label.setSize(300, 300);

        MapDay3Label.setVisible(true);
        MapDay3Label.setIcon(MapByFour);
        MapDay3Label.setLocation(590,265);
        MapDay3Label.setSize(300, 300);

        MapDay2Label.setVisible(true);
        MapDay2Label.setIcon(LongMapByFour);
        MapDay2Label.setLocation(507,245);
        MapDay2Label.setSize(300, 300);

        MainGamePanel.add(BACKGROUND_PANEL,Integer.valueOf(0));
        MainGamePanel.add(EXIT_BUTTON, Integer.valueOf(2));
        MainGamePanel.add(MapDay1Label, Integer.valueOf(2));
        MainGamePanel.add(MapDay2Label, Integer.valueOf(2));
        MainGamePanel.add(MapDay3Label, Integer.valueOf(2));
        MainGamePanel.add(PopupLabel, Integer.valueOf(2));
        MainGamePanel.add(MapTest1, Integer.valueOf(3));
//        MainGamePanel.add(Day0, Integer.valueOf(3));
//        MainGamePanel.add(D1C1, Integer.valueOf(3));
//        MainGamePanel.add(D1C2, Integer.valueOf(3));

        this.add(MainGamePanel);


    }

//    private class HandlerClass0 implements MouseListener {
//        @Override public void mouseClicked(MouseEvent e) {}
//        @Override public void mousePressed(MouseEvent e) {}
//        @Override public void mouseReleased(MouseEvent e) {}
//        @Override public void mouseEntered(MouseEvent e) {
//            PopupLabel.setText(String.format("Day 0: Trail Choice"));}
//        @Override public void mouseExited(MouseEvent e) {
//            PopupLabel.setText(String.format("Day: "));}
//    }
//    private class HandlerClass1C1 implements MouseListener {
//        @Override public void mouseClicked(MouseEvent e) {}
//        @Override public void mousePressed(MouseEvent e) {}
//        @Override public void mouseReleased(MouseEvent e) {}
//        @Override public void mouseEntered(MouseEvent e) {
//            PopupLabel.setText(String.format("Day 1: Left Trail Choice"));}
//        @Override public void mouseExited(MouseEvent e) {
//            PopupLabel.setText(String.format("Day: "));}
//    }
//    private class HandlerClass1C2 implements MouseListener {
//        @Override public void mouseClicked(MouseEvent e) {}
//        @Override public void mousePressed(MouseEvent e) {}
//        @Override public void mouseReleased(MouseEvent e) {}
//        @Override public void mouseEntered(MouseEvent e) {
//            PopupLabel.setText(String.format("Day 1: Right Trail Choice"));}
//        @Override public void mouseExited(MouseEvent e) {
//            PopupLabel.setText(String.format("Day: "));}
//    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == EXIT_BUTTON){
            this.dispose();
        }


    }

}