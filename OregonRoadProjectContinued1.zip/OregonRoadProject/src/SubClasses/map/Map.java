package SubClasses.map;
import RoadStart.DayOne.TrailChoice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



public class Map extends JFrame implements ActionListener{

    JButton EXIT_BUTTON = new JButton("EXIT");
    JLayeredPane MainGamePanel;
    JPanel BACKGROUND_PANEL = new JPanel();


    static final int GAME_WIDTH = 500;
    static final int GAME_HEIGHT = 400;
    static final Dimension SCREEN_SIZE = new Dimension(GAME_WIDTH, GAME_HEIGHT);

    JLabel MapDay1Label = new JLabel();
    JLabel MapDay2Label = new JLabel();
    ImageIcon  MapDay1 = new ImageIcon("Map.png");
    ImageIcon MapDay2 = new ImageIcon("MapDay2.png");



    public Map(){

        MainGamePanel = new JLayeredPane();
        MainGamePanel.setPreferredSize(SCREEN_SIZE);


        this.setPreferredSize(SCREEN_SIZE);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setTitle("Map");
        this.setResizable(false);
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);

        BACKGROUND_PANEL.setOpaque(true);
        BACKGROUND_PANEL.setSize(SCREEN_SIZE);
        BACKGROUND_PANEL.setBackground(new Color(50,50,50));

        EXIT_BUTTON.setVisible(true);
        EXIT_BUTTON.setBounds(400,300,100,50);
        EXIT_BUTTON.setBackground(new Color(0,250,0));
        EXIT_BUTTON.setFocusable(false);
        EXIT_BUTTON.setFont(new Font("Arial", Font.BOLD, 10));
        EXIT_BUTTON.addActionListener(this);



        MapDay1Label.setVisible(true);
        MapDay1Label.setIcon(MapDay1);
        MapDay1Label.setLocation(150,150);
        MapDay1Label.setSize(300, 300);

        MapDay2Label.setVisible(true);
        MapDay2Label.setIcon(MapDay2);
        MapDay2Label.setLocation(200,200);
        MapDay2Label.setSize(100, 100);

        MainGamePanel.add(BACKGROUND_PANEL,Integer.valueOf(0));
        MainGamePanel.add(EXIT_BUTTON, Integer.valueOf(2));
        MainGamePanel.add(MapDay1Label, Integer.valueOf(2));
        MainGamePanel.add(MapDay2Label, Integer.valueOf(2));

        this.add(MainGamePanel);

    }


    @Override

    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == EXIT_BUTTON){
            this.dispose();
        }


    }

}