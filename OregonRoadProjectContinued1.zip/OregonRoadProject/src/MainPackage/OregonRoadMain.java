package MainPackage;

import RoadStart.DayTwo.*;
import ShopAsking.*;
import RoadStart.DayOne.*;
import ShopAsking.ShopItemsSpecific.*;
import SubClasses.InsideWagon.InsideWagonStuff;
import SubClasses.Results.*;
import SubClasses.map.Map;


public class OregonRoadMain {

    static boolean START = false;
    static String difficulty = "";
    static int money = 0;
    static int food = 0;
    static int miles = 2000;
    static int days = 0;
    static boolean ShopsBeenAsked = false;

    static int ResultCall = 0;

    //shop items
    static int Bandages = 0;
    static int Measles = 0;
    static int Dissentray = 0;
    static int Flu = 0;
    static int Wheel = 0;
    static int Horse = 0;
    static int Cloth = 0;
    static int Steering = 0;
    static int Shotgun= 0;
    static int Shotgun_ammo= 0;


    public static void main(String [] args){

        if(START == false){
            OregonRoadDrawn DrawBegin = new OregonRoadDrawn();
            START = true;
        }
    }

    public static void DrawFirstPicture(){
        Customize FIRST = new Customize();
    }

    public static void JourneyStart(Object Season_choice, Object Food_choice, Object Money_choice){



        if(Season_choice.toString() == "summer(normal)"){
            difficulty = "normal";
        }
        if(Season_choice.toString() == "winter(hard)"){
            difficulty = "hard";
        }
        if(Season_choice.toString() == "spring(normal)"){
            difficulty = "normal";
        }
        if(Season_choice.toString() == "autumn(easy)"){
            difficulty = "easy";
        }
        if (Food_choice.toString() == "normal"){
            food = 300;
        }
        if (Food_choice.toString() == "to much"){
            food = 600;
        }
        if (Food_choice.toString() == "not enough"){
            food = 100;
        }
        if(Money_choice.toString() == "rich"){
            money = 500;
        }
        if(Money_choice.toString() == "poor"){
            money = 100;
        }
        if(Money_choice.toString() == "wealthy"){
            money = 300;
        }

        if(ShopsBeenAsked == false){
            ShopAsk SA = new ShopAsk(money, food, miles, days, difficulty);
            ShopsBeenAsked = true;

        }

    }

    public static void ShopAskAnswer(String choice){
        if(choice.equals("yes")){
            ShopItems SI = new ShopItems(money, food, miles, days, difficulty);
        }
        if(choice.equals("no")){
            days = days + 1;
            TrailChoice TC = new TrailChoice(money, food, miles, days, difficulty);
        }

    }
    public static void ShopItemsAnswer(int i, int choice){

        if(choice == 1){
            Ammo_Guns SI = new Ammo_Guns(money, food, miles, days, difficulty);
        }
        if(choice == 2){
            Food TC = new Food(money, food, miles, days, difficulty);
        }
        if(choice == 3){
            Medicine SI = new Medicine(money, food, miles, days, difficulty);
        }
        if(choice == 4){
            WagonParts TC = new WagonParts(money, food, miles, days, difficulty);
        }

    }

    public static void ShopItemBought(int choice, int Descison){
        if(Descison == 1){ // ammo / gun
            if(choice == 1){
                Shotgun++;
                money = money - 40;
            }
            else if(choice == 2){
                Shotgun_ammo = Shotgun_ammo + 20;
                money = money - 25;
            }
            else if(choice == 3){
                Shotgun_ammo = Shotgun_ammo + 15;
                money = money - 20;
            }
            else if(choice == 4){
                Shotgun_ammo = Shotgun_ammo + 30;
                money = money - 30;
            }
        }
        else if(Descison == 2){ // food
            if(choice == 1){
                food = food + 50;
                money = money - 20;
            }
            else if(choice == 2){
                food = food + 125;
                money = money - 50;
            }
            else if(choice == 3){
                food = food + 100;
                money = money - 40;
            }
            else if(choice == 4){
                food = food + 150;
                money = money - 75;
            }
        }
        else if(Descison == 3){ // medicine
            if(choice == 1){
                Bandages = Bandages + 5;
                money = money - 10;
            }
            else if(choice == 2){
                Measles++;
                money = money - 20;
            }
            else if(choice == 3){
                Flu++;
                money = money - 20;
            }
            else if(choice == 4){
                Dissentray++;
                money = money - 20;
            }
        }
        else if(Descison == 4){ // wagon parts
            if(choice == 1){
                Wheel++;
                money = money - 25;
            }
            else if(choice == 2){
                Horse++;
                money = money - 50;
            }
            else if(choice == 3){
                Cloth++;
                money = money - 75;
            }
            else if(choice == 4){
                Steering++;
                money = money - 35;
            }
        }

        ShopAsk SAS = new ShopAsk(money, food, miles, days, difficulty);
    }

    public static void CallSubClassWagon(){
        InsideWagonStuff IWS = new InsideWagonStuff(Bandages, Measles, Dissentray, Flu,
                Wheel, Horse, Cloth, Steering,
                Shotgun, Shotgun_ammo);

    }
    public static void CallSubClassMap(){
        Map M = new Map();

    }
    public static void GetResult(int choice){

        ResultCall = ResultCall + 1;
        String info = "";

        if(ResultCall == 1){
                if (choice == 1) {
                    info = "you chose the left path and go on a faster routte -1 day";
                    Result1 R1 = new Result1(info);
                }
                if (choice == 2) {
                    info = "you chose the right path and go on a normal routte";
                    Result2 R2 = new Result2(info);
            }
        }

    }

    public static void CheckDay(){

        boolean DayOne = false;

        if(DayOne == false){
            DayOne = true;
            days = days + 1;
            StrangerMeetUp SM = new StrangerMeetUp(money, food, miles, days, difficulty);
        }
    }




}